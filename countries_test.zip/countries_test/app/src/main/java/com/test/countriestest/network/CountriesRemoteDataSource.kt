package com.test.countriestest.network

import com.test.countriestest.network.models.CountriesModel
import com.test.countriestest.network.models.Result
import retrofit2.Response
import retrofit2.Retrofit
import javax.inject.Inject

class CountriesRemoteDataSource @Inject constructor(private val retrofit: Retrofit) {

    suspend fun fetchCountries(): Result<CountriesModel> {
        val countryService = retrofit.create(CountriesService::class.java);
        return getResponse(
            request = { countryService.getCountries() },
            defaultErrorMessage = "Error fetching Movie list"
        )

    }


    private suspend fun <T> getResponse(
        request: suspend () -> Response<T>,
        defaultErrorMessage: String
    ): Result<T> {
        return try {
            val result = request.invoke()
            if (result.isSuccessful) {
                return Result.success(result.body())
            } else {
                Result.error(defaultErrorMessage, null)
            }
        } catch (e: Throwable) {
            Result.error(defaultErrorMessage, null)
        }
    }
}