package com.test.countriestest.data.repo

import com.test.countriestest.network.CountriesRemoteDataSource
import com.test.countriestest.network.models.Result
import com.test.countriestest.network.models.CountriesModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject


class CountryRepository @Inject constructor(
    private val countriesSource: CountriesRemoteDataSource
) {

    suspend fun fetchCountries(): Flow<Result<CountriesModel>?> {
        return flow {
            emit(Result.loading())
            val result = countriesSource.fetchCountries()
            emit(result)
        }.flowOn(Dispatchers.IO)
    }

}