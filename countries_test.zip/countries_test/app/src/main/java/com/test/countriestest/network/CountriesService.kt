package com.test.countriestest.network

import com.test.countriestest.network.models.CountriesModel
import retrofit2.Response
import retrofit2.http.GET


interface CountriesService {

    @GET("/v3.1/all")
    suspend fun getCountries(): Response<CountriesModel>


}