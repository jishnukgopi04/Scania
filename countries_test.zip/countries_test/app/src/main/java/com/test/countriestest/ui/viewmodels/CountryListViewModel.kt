package com.test.countriestest.ui.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.test.countriestest.network.models.CountriesModel
import com.test.countriestest.data.repo.CountryRepository
import com.test.countriestest.network.models.Result
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CountryListViewModel @Inject constructor(private val countryRepository: CountryRepository) :
    ViewModel() {

    private val _countries = MutableLiveData<Result<CountriesModel>>()
    val countries = _countries

    init {
        fetchCountries()
    }

    private fun fetchCountries() {
        viewModelScope.launch {
            countryRepository.fetchCountries().collect {
                _countries.value = it
            }
        }
    }
}