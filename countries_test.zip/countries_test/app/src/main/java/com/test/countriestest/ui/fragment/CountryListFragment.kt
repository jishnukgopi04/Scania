package com.test.countriestest.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.test.countriestest.network.models.CountriesModel
import com.test.countriestest.ui.viewmodels.CountryListViewModel
import com.test.countriestest.R
import com.test.countriestest.network.models.Result
import com.test.countriestest.databinding.FragmentCountryListBinding
import com.test.countriestest.databinding.ItemCountryBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CountryListFragment : Fragment() {


    private val model: CountryListViewModel by viewModels()
    private lateinit var mBinding: FragmentCountryListBinding
    private lateinit var adapter: CountryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = CountryAdapter(mutableListOf()) {
            val bundle = bundleOf("coatOfArms" to it.coatOfArms!!.png)
            findNavController().navigate(R.id.list_to_detail, bundle)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mBinding = FragmentCountryListBinding.inflate(
            LayoutInflater.from(requireActivity()),
            container,
            false
        )
        return mBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mBinding.list.adapter = adapter
        model.countries.observe(viewLifecycleOwner, Observer {
            when (it.status) {
                Result.Status.SUCCESS -> {
                    hideProgress()
                    adapter.list.clear()
                    adapter.list.addAll(it.data as ArrayList<CountriesModel.CountriesModelItem>)
                    adapter.notifyDataSetChanged()
                }
                Result.Status.ERROR -> {
                    hideProgress()
                    Toast.makeText(requireActivity(), it.message, Toast.LENGTH_SHORT).show()
                }
                Result.Status.LOADING -> {
                    showProgress()
                }
            }
        })
    }


    fun showProgress() {
        mBinding.progress.visibility = View.VISIBLE
    }

    fun hideProgress() {
        mBinding.progress.visibility = View.GONE
    }

}


class CountryAdapter(
    val list: MutableList<CountriesModel.CountriesModelItem>,
    val listener: (CountriesModel.CountriesModelItem) -> Unit
) :
    RecyclerView.Adapter<CountryVH>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryVH {
        return CountryVH(
            ItemCountryBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            ), listener
        )
    }

    override fun onBindViewHolder(holder: CountryVH, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemCount(): Int {
        return list.size
    }
}

class CountryVH(
    val binding: ItemCountryBinding,
    val listener: (CountriesModel.CountriesModelItem) -> Unit
) : RecyclerView.ViewHolder(binding.root) {


    var model: CountriesModel.CountriesModelItem? = null

    companion object {
        val NAME = "Name : "
        val CAPITAL = "Capital : "
        val REGION = "Region : "
    }

    init {
        binding.root.setOnClickListener {
            listener(model!!)
        }
    }

    fun bind(model: CountriesModel.CountriesModelItem) {
        this.model = model
        Glide.with(itemView).load(model.flags!!.png).into(binding.img)
        binding.name.setText(NAME + " " + model.name!!.common)
        binding.capital.setText(CAPITAL + " " + model.capital)
        binding.region.setText(REGION + " " + model.region)
    }

}