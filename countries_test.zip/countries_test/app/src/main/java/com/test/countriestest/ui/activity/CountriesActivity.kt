package com.test.countriestest.ui.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.test.countriestest.R
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CountriesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}